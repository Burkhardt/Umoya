# umoya-resources
It contains umoya resources like templates, test-data and icons for data, model and code.
